# Orbital Atlas — Voyager 1

Пакет для монтажа • 10 ноября 2026 • 16:9, 1920×1080, 30 fps • Adam, EN-US  
Цель по монтажу 3:10–3:40. Таймкоды после хука уточнить по фактической озвучке.

## Три варианта обложки и заголовка

| Вариант | Заголовок | Обложка и первый кадр |
|---|---|---|
| A — выбран | Why NASA Has to Wait 48 Hours to Hear Back From Voyager 1 | На чёрном фоне крупная тарелка Voyager справа, крошечная Земля слева, между ними тонкая линия связи и крупное **48 HOURS**. За основу зонда взять A1, пометка ARTIST CONCEPT. |
| B | NASA Lost Contact With Voyager 1. Then the Signal Came Back. | Реальная архивная фотография Voyager в испытательной камере, пустой индикатор слева, **SIGNAL LOST**. Индикатор условный. |
| C | NASA’s Voyager 1 Is About to Reach One Light-Day From Earth | Зонд и Земля на концах одной траектории, яркая точка посередине, **24H ONE WAY**. Пометка SCHEMATIC. |

Обложку A экспортировать из кадра 0. На 0:00.30 начинается движение по линии. К 0:01.20 текст уходит вслед за движением камеры. Без отдельной заставки.

## Сценарий для Adam

**0:00–0:24 — cold open**

Send a radio command to NASA’s Voyager 1 and, by November eighteenth, it’ll take a full day just to get there. If the spacecraft replies right away, that answer takes another day to get back. In October, NASA listened twice and heard nothing. And before engineers sent a troubleshooting command, the signal came back on its own.

**0:24–0:58 — three listening windows**

On October eighteenth, NASA’s Deep Space Network pointed its antennas at Voyager’s patch of sky. It didn’t detect a signal. Twenty-four hours later, the team tried again. Still nothing. On the twentieth, the signal reappeared.

Once engineers could see what the spacecraft had been doing, they found a clue. One group of thrusters had gone offline, and its backup had switched on. Voyager is programmed to make that switch automatically. What triggered the outage was still under investigation when NASA reported it.

**0:58–1:37 — the round trip**

Here’s what makes troubleshooting Voyager so different from troubleshooting a spacecraft near Earth. The first day goes by while your command is still on its way. At the end of that day, the spacecraft finally hears you. If it responds immediately, the second day goes by while the answer is still on its way home.

That’s forty-eight hours of travel time alone. And if the answer tells you to try something different, the next command starts the whole trip again.

On November eighteenth, Voyager will be about sixteen billion miles from Earth. That distance is one light-day. There’s no marker out there for Voyager to cross. The milestone is what that distance does to a conversation.

**1:37–2:18 — keeping Voyager alive**

In September, the engineers pulled off a different kind of repair. As Voyager’s power supply dwindles, every watt matters. They switched off three devices and turned on three lower-power replacements. Those devices help keep the spacecraft warm, so the team needed to make all three swaps together to keep the heat distributed properly.

The change bought breathing room. Without it, NASA says it might have had to turn off another science instrument as early as the summer of twenty twenty-seven.

**2:18–3:15 — the distance made visible**

Voyager left Earth in nineteen seventy-seven. It flew past Jupiter and Saturn. In nineteen ninety, it looked back and took this picture. That little speck is Earth. It had already taken hours for light to cross the gap between home and the spacecraft.

In twenty twelve, Voyager crossed the heliopause, the edge of the bubble shaped by the solar wind. It’s been sampling interstellar space ever since.

Now look at the timeline one more time. At hour zero, a signal leaves Earth. At hour twenty-four, Voyager hears it. At hour forty-eight, Earth can hear back. For a spacecraft launched in the nineteen seventies, that last moment is the remarkable part. After two days of waiting, there’s still something on the other end of the line.

## Монтаж и звук

| Таймкод | Изображение и движение | Звук и маркировка |
|---|---|---|
| 00:00–00:03 | Обложка A → непрерывный пролёт вдоль линии связи. Начало Adam с первого такта. | Короткий синтезированный щелчок на старте сигнала. ARTIST CONCEPT. |
| 00:03–00:08 | Камера отходит к Земле, импульс уходит по дуге. На зонде появляется **24H TO REACH IT**. | Один импульс, тихий низкий фон. SCHEMATIC. |
| 00:08–00:12 | Сигнал разворачивается в обратном направлении. Линия заполняет вторую половину шкалы. **48H ROUND TRIP**. | Второй импульс с иной высотой. SCHEMATIC. |
| 00:12–00:18 | Перебивка на A2. На переднем плане последовательность **OCT 18 / OCT 19 / NO SIGNAL**. | На втором NO SIGNAL фон затихает. ARCHIVE PHOTO. |
| 00:18–00:24 | **OCT 20**. Возвращается тонкая линия. Склейка по её движению в реальный архивный кадр A3. | Короткий синтезированный тон возвращения. Интерфейс условный. |
| 00:24–00:58 | Две пустые отметки и третья с сигналом. На фото A3 показать схематическую вставку с двумя группами двигателей ориентации и переключением. | Плашка **CAUSE UNDER INVESTIGATION**. Фото A3 подписать «one of the Voyager spacecraft». |
| 00:58–01:37 | Один проезд по шкале **SEND → ARRIVE → REPLY RECEIVED**. Часы 0 / 24 / 48 раскрываются по ходу реплики. В конце отъезд до масштаба **~16 BILLION MILES**. | SCHEMATIC / DISTANCES NOT TO SCALE. 48 часов при немедленном ответе. |
| 01:37–02:18 | Архивное фото + собственная схема из трёх пар модулей. Три переключения в один такт, затем отметка **LESS POWER USED**. | Схему подписать SIMPLIFIED. Не придумывать значения экономии. |
| 02:18–02:45 | Траектория A4 → движущиеся облака Юпитера A5 → A6 с аккуратным выделением Земли. | На A5 сохранить кредит страницы. На A6 **VOYAGER 1 PHOTO · 1990**. |
| 02:45–финал | Собственная схема гелиопаузы → возвращение к первому кадру. Обратный импульс доходит до Земли на последней фразе. | Последний синтезированный тон и короткое затухание. |

## Исходники и проверка

- A1 — [PIA17462, Voyager 1 artist concept](https://www.jpl.nasa.gov/images/pia17462-voyager-1-entering-interstellar-space-artist-concept/). NASA/JPL-Caltech. Кадрирование для обложки и первых секунд.
- A2 — [DSS43, фото антенны сети дальней связи](https://www.jpl.nasa.gov/images/pia23682-nasas-deep-space-antenna-upgrade-to-affect-voyager/). Иллюстрация сети, конкретную антенну октябрьских сеансов по этому фото не идентифицировать. Кредит по подписи карточки.
- A3 — [JPL, архивное фото испытательной камеры в новости от 29 октября](https://www.jpl.nasa.gov/news/nasas-voyager-1-conserves-power-resolves-brief-communications-pause/). NASA/JPL-Caltech. На фото один из аппаратов Voyager.
- A4 — [NASA SVS 4139, траектория Voyager 1](https://svs.gsfc.nasa.gov/4139/). Брать чистую визуализацию и кредит с карточки. Траектория архивная.
- A5 — [NASA SVS 3611, облака Юпитера, серия Voyager 1](https://svs.gsfc.nasa.gov/3611/). Визуализация по снимкам миссии. Кредит по карточке.
- A6 — [NASA, Pale Blue Dot, оригинал и обработанная версия](https://science.nasa.gov/resource/voyager-pale-blue-dot-download/). Кредит по выбранной версии.
- [NASA, время вехи](https://science.nasa.gov/mission/voyager/voyager-1/voyager-1-what-is-a-light-day/). 18 ноября 2026, 05:16 EST = 10:16 UTC = 17:16 по Вьетнаму. Один световой день = 24 часа в одну сторону.
- [NASA, история миссии](https://science.nasa.gov/mission/voyager/voyager-1/).
- [NASA Media Guidelines](https://www.nasa.gov/nasa-brand-center/images-and-media/) и [JPL Image Use Policy](https://www.jpl.nasa.gov/jpl-image-use-policy/). Сверить кредит и исключения каждой карточки при загрузке. Плашки миссии и стороннюю музыку не переносить.

## Сдача в монтаж

Сначала отрендерить 0:00–0:24. Проверить кадр 0 против экспорта обложки, считываемость 24/48 на iPad и непрерывность движения. Далее собрать полный ролик по тому же макету и синхронизировать таймкоды по Adam. В этой версии в пакете есть отобранные файлы, обложка и 21-секундный аниматик. Озвучку Adam и полный монтаж собрать на следующем этапе.
