/* Frame-addressable editorial motion reference. Coordinates use a 1280x720 stage. */
const c = document.querySelector("canvas");
const g = c.getContext("2d");
const W = 1280, H = 720;
const PI = Math.PI;
const cfg = window.EPISODE;
const media = {};
const pal = {ice:"#a4e8ff", paper:"#f7f1e5", red:"#ff6048", lime:"#c6ff69", amber:"#ffb364"};
const clamp = (x, lo=0, hi=1) => Math.min(hi, Math.max(lo,x));
const smooth = x => { x=clamp(x); return x*x*(3-2*x); };
const lerp = (a,b,p) => a+(b-a)*p;
const range = (t,a,b) => smooth((t-a)/(b-a));
const rand = i => { const x=Math.sin(i*117.83+23.98)*43758.54; return x-Math.floor(x); };
function text(s,x,y,n=28,color=pal.paper,weight=700,align="left",mono=false) {
  g.fillStyle=color; g.font=weight+" "+n+"px "+(mono?"monospace":"system-ui, sans-serif");
  g.textAlign=align; g.textBaseline="alphabetic"; g.fillText(s,x,y);
}
function line(points,color,w=2,dash=[]) {
  g.strokeStyle=color; g.lineWidth=w; g.lineJoin="round"; g.lineCap="round"; g.setLineDash(dash);
  g.beginPath(); points.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y)); g.stroke(); g.setLineDash([]);
}
function circle(x,y,r,fill,stroke,w=1) {
  g.beginPath(); g.arc(x,y,r,0,PI*2);
  if(fill){g.fillStyle=fill;g.fill();} if(stroke){g.strokeStyle=stroke;g.lineWidth=w;g.stroke();}
}
function box(x,y,w,h,fill,stroke) {
  if(fill){g.fillStyle=fill;g.fillRect(x,y,w,h);}
  if(stroke){g.strokeStyle=stroke;g.lineWidth=1;g.strokeRect(x,y,w,h);}
}
function pill(s,x,y,color=pal.paper) {
  g.font="700 16px monospace";
  const w=g.measureText(s).width+24;
  box(x,y-24,w,31,"#080a0de8",color+"55");
  text(s,x+12,y-3,16,color,700,"left",true);
}
function gradient(stops,x=0,y=0,xx=W,yy=0) {
  const grad=g.createLinearGradient(x,y,xx,yy); stops.forEach(([p,col])=>grad.addColorStop(p,col));return grad;
}
function background(a="#090e1c",b="#03060d") {
  box(0,0,W,H,gradient([[0,a],[1,b]],0,0,W,H));
}
function image(name,x=0,y=0,w=W,h=H,zoom=1,fx=.5,fy=.5) {
  const im=media[name]; if(!im) return;
  const iw=im.videoWidth||im.naturalWidth, ih=im.videoHeight||im.naturalHeight;
  if(!iw||!ih) return;
  const sw=Math.min(iw,ih*w/h)/zoom, sh=sw*h/w;
  g.drawImage(im,(iw-sw)*fx,(ih-sh)*fy,sw,sh,x,y,w,h);
}
function glow(x,y,r,col) {
  const gr=g.createRadialGradient(x,y,0,x,y,r);
  gr.addColorStop(0,col+"bb");gr.addColorStop(.19,col+"55");gr.addColorStop(1,col+"00");
  circle(x,y,r,gr);
}
function vignette() {
  const v=g.createRadialGradient(640,355,245,640,355,735);
  v.addColorStop(0,"#0000");v.addColorStop(1,"#0009");box(0,0,W,H,v);
}
function grid(s=48,col="#a4e8ff13",drift=0) {
  for(let x=drift%s;x<W;x+=s)line([[x,0],[x,H]],col,1);
  for(let y=0;y<H;y+=s)line([[0,y],[W,y]],col,1);
}
function starfield(t=0) {
  for(let i=0;i<100;i++){
    const x=(rand(i)*W+t*(5+rand(i+100)*12))%W, y=rand(i+200)*H;
    circle(x,y,.4+rand(i+300)*1.35,"rgba(193,226,255,"+(.17+rand(i+400)*.6)+")");
  }
}
function footer(label,credit="",accent=pal.ice) {
  line([[54,657],[1226,657]],"#d9efff32",1);
  text(label,54,684,15,accent,700,"left",true);
  if(credit) text(credit,1226,684,15,"#d9e1e6",500,"right",true);
}
function big(s,x,y,n=100,color=pal.paper) { text(s,x,y,n,color,900); }
function kick(s,x=55,y=65,color=pal.ice) {text(s,x,y,18,color,750,"left",true);}
function signal(t) {
  if(t<3.05){
    image("voyager",0,0,W,H,1+.09*range(t,.2,3.05),.72,.43);
    box(0,0,W,H,gradient([[0,"#030915f7"],[.47,"#041321bc"],[.77,"#04132100"]]));
    const fade=1-range(t,1.05,2.82), x=57-56*range(t,1,2.7);
    g.save();g.globalAlpha=fade; kick("N A S A   /   V O Y A G E R  1",x,83);
    big("48",x,330,212);big("HOURS",x+6,421,89);text("FOR A ROUND TRIP",x+9,473,22,pal.ice,700,"left",true);g.restore();
    const p=range(t,.65,3.05);line([[68,554],[1190,554]],"#84c4e963",2);
    glow(lerp(73,1170,p),554,44,pal.ice);circle(lerp(73,1170,p),554,4,pal.ice);
    footer("ARTIST CONCEPT","NASA / JPL-CALTECH");return;
  }
  if(t<11.4){
    background("#102039","#060913"); starfield(t); grid(50,"#a4e8ff10",t*9);
    const leg=t<7.25?0:1, p=range(t,leg?7.28:3.18,leg?11.12:7.06);
    const ax=215,bx=1066,y=363,px=leg?lerp(bx,ax,p):lerp(ax,bx,p);
    kick("SIGNAL TRAVEL TIME  /  EARTH ↔ VOYAGER 1");
    line([[ax,y],[bx,y]],"#75abc47a",2,[8,12]);
    line([[leg?bx:ax,y],[px,y]],leg?pal.amber:pal.ice,3);
    glow(ax,y,102,"#287ada");circle(ax,y,57,"#0f447c","#7bc8ff",2);
    g.save();g.beginPath();g.arc(ax,y,56,0,PI*2);g.clip();
    for(let i=0;i<6;i++)line([[ax-50,y-42+i*18],[ax+6,y-48+i*19],[ax+45,y-35+i*19]],"#80d4e94f",5);
    g.restore();circle(bx,y,30,"#162d43","#9ee9ff",2);circle(bx,y,8,pal.ice);
    glow(px,y,60,leg?pal.amber:pal.ice);circle(px,y,8,leg?pal.amber:pal.ice);
    text("EARTH",ax,460,23,pal.paper,800,"center",true);text("VOYAGER 1",bx,460,23,pal.paper,800,"center",true);
    text(leg?"48H ROUND TRIP":"24H ONE WAY",640,235,74,leg?pal.amber:pal.ice,850,"center");
    text(leg?"REPLY RETURNING":"COMMAND OUTBOUND",640,537,23,pal.paper,600,"center",true);
    footer("SCHEMATIC  /  NOT TO SCALE");return;
  }
  image(t<17.2?"dish":"voyager_archive",0,0,W,H,1.01+.08*range(t,11.4,21),.57,.46);
  box(0,0,W,H,gradient([[0,"#020912f8"],[.63,"#020912cc"],[1,"#02091215"]]));
  kick("DEEP SPACE NETWORK  /  OCTOBER 2026");
  const dates=["OCT 18","OCT 19","OCT 20"];
  for(let i=0;i<3;i++){
    const a=range(t,[11.48,14.08,17.23][i],[12.03,14.65,17.80][i]);if(a===0)continue;
    const y=210+121*i;
    g.save();g.globalAlpha=a; box(55,y-49,679,83,"#061019d8","#96c9e745");
    text(dates[i],80,y+3,29,pal.paper,750,"left",true);
    text(i===2?"SIGNAL BACK":"NO SIGNAL",303,y+4,36,i===2?pal.ice:pal.red,850);
    circle(691,y-7,5,i===2?pal.ice:pal.red);g.restore();
  }
  footer("ARCHIVE PHOTO",t<17.2?"NASA / CANBERRA DEEP SPACE COMMUNICATION COMPLEX":"NASA / JPL-CALTECH");
}
function moon(t){
  if(t<6.3){
    background("#211c21","#09080b");
    image("moon_notes",504-97*range(t,1.7,6.2),112-52*range(t,1.7,6.2),716+328*range(t,1.7,6.2),402+184*range(t,1.7,6.2));
    const a=1-range(t,2.3,4.8);g.save();g.globalAlpha=a;
    box(0,0,W,H,gradient([[0,"#120e14ff"],[.39,"#120e14e2"],[.66,"#120e1400"]]));
    kick("A R T E M I S   I I",56,88,"#ff8069");big("FIVE",51,313,156);big("FLASHES",57,413,84);
    text("ON THE FAR SIDE",60,473,23,"#ff8069",750,"left",true);g.restore();
    if(t>3.6)pill("CREW ANNOTATIONS",55,612,"#ff9e85");
    footer("ANNOTATED SIMULATION","NASA", "#ff9e85");return;
  }
  if(t<10.6){
    image("flyby",0,0,W,H,1+.035*range(t,6.3,10.6),.51,.51);vignette();
    box(0,0,W,121,gradient([[0,"#08060be6"],[1,"#08060b00"]],0,0,0,121));
    kick("ORION’S VIEW  /  DARK LUNAR SURFACE",55,66,"#ff9e85");
    footer("NASA FLYBY MATERIAL","NASA / SCIENTIFIC VISUALIZATION STUDIO","#ff9e85");return;
  }
  if(t<15.6){
    background("#171923","#070810");starfield(t*.2);
    const p=range(t,10.75,15.4), a=lerp(-1.1,1.04,p), mx=754,my=350;
    const ox=mx+248*Math.cos(a),oy=my+248*Math.sin(a);
    kick("WHEN THE MOON BLOCKS THE RADIO PATH",55,70,"#ff9e85");
    line([[199,my],[ox,oy]],p>.32&&p<.78?pal.red:"#91c5e3",2,[9,12]);
    circle(mx,my,248,null,"#8399a34f",1);circle(mx,my,126,"#171921","#9f9aa4",2);
    circle(mx-31,my-23,85,"#2a2931");circle(mx-28,my-42,43,"#23242c");
    circle(199,my,32,"#245c9c","#93d7f7",2);circle(ox,oy,9,pal.paper);
    text("EARTH",199,my+70,19,pal.paper,750,"center",true);
    text("MOON",mx,my+172,19,pal.paper,750,"center",true);
    text("ORION",ox+22,oy-13,19,pal.paper,750,"left",true);
    text("PLANNED RADIO BLACKOUT",56,586,40,pal.red,850);
    footer("SCHEMATIC  /  NOT TO SCALE","","#ff9e85");return;
  }
  background("#241e23","#0a090c");
  const z=1+.085*range(t,15.6,21);
  image("moon_notes",380,92,842,474,z,.51,.47);
  line([[380,583],[1221,583]],"#ff9e8577",1);
  kick("FLYBY OBSERVATION  /  CREW RECORD",55,66,"#ff9e85");
  big("46,000",50,324,81);text("MILES AWAY",55,375,29,"#ff9e85",800,"left",true);
  text("Approximate distance",56,419,18,"#e4dbd9",500);
  footer("ANNOTATED SIMULATION","NASA","#ff9e85");
}
function annulus(t, cx=790, cy=362,r=163){
  const ring=gradient([[0,"#252d34"],[.39,"#91a0a8"],[.6,"#242b31"],[1,"#535359"]],cx-r,cy-r,cx+r,cy+r);
  for(let i=4;i>=0;i--)circle(cx+i*2,cy+i*4,r+i*3,i===0?ring:"#16191e","#bac8ca35",1);
  circle(cx,cy,r*.58,"#0c1016","#a9b5bb",3);
  circle(cx,cy,r*.83,null,"#0a0e15",35);
  const a=t*2.65-.9;
  for(let i=0;i<16;i++){
    const q=(i/16)*PI*2;const x=cx+Math.cos(q)*r*.83,y=cy+Math.sin(q)*r*.83;
    circle(x,y,2,"#78d4ff80");
  }
  g.beginPath();g.arc(cx,cy,r*.83,a-.72,a);g.strokeStyle="#ff572e";g.lineWidth=17;g.stroke();
  const hx=cx+Math.cos(a)*r*.83,hy=cy+Math.sin(a)*r*.83;
  glow(hx,hy,79,"#ff5d35");circle(hx,hy,9,"#fff2c3");
  const ox=cx+Math.cos(a)*r*1.26,oy=cy+Math.sin(a)*r*1.26;
  line([[hx,hy],[ox,oy]],pal.amber,2);circle(ox,oy,3,pal.amber);
  return [hx,hy];
}
function detonation(t) {
  if(t<3.65 || t>=13.1){
    const isIntro=t<3.65; image("hotfire",0,0,W,H,1+.05*range(t,0,3.65),.47,.53);
    box(0,0,W,H,isIntro?gradient([[0,"#120908c2"],[.42,"#12090804"],[.61,"#12090818"],[1,"#120908ff"]],0,0,0,H):gradient([[0,"#120908f4"],[.41,"#120908c3"],[.8,"#1209081c"]]));
    if(isIntro){
      g.save();g.globalAlpha=1-range(t,1.45,3.6);
      kick("NASA  /  MARSHALL SPACE FLIGHT CENTER",55,80,"#ff8c69");
      box(56,462,7,138,pal.red);
      big("DETONATION",78,557,104);
      text("3D-PRINTED COMBUSTOR",83,599,21,"#ff956e",800,"left",true);g.restore();
    } else{
      kick("FULL-SCALE COMBUSTOR  /  2023",55,74,"#ff8c69");
      big("251",48,379,218);big("SECONDS",61,455,73);
      text("4 MIN 11 SEC ON THE TEST STAND",60,521,21,"#ff956e",700,"left",true);
    }
    footer("REAL HOT-FIRE  /  EXCERPT","NASA / MARSHALL SPACE FLIGHT CENTER","#ff956e");return;
  }
  background("#241717","#090d14");grid(48,"#ff886612",t*6);
  kick("ROTATING DETONATION  /  FRONT VIEW",55,71,"#ff8c69");
  annulus(t,804,356,176);
  big("FIRE",49,319,109);big("IN A LOOP",56,394,62);
  text(t<8.4?"WAVEFRONT ROTATES":"FRESH PROPELLANT FEEDS IT",59,463,21,pal.ice,750,"left",true);
  if(t>=8.4){
    for(let i=0;i<5;i++){
      const a=(i/5)*PI*2+t*.17;
      const r=205+29*Math.sin(t*4+i), x=804+Math.cos(a)*r,y=356+Math.sin(a)*r;
      line([[x,y],[lerp(x,804,.18),lerp(y,356,.18)]],pal.ice,3);
    }
  }
  footer("SIMPLIFIED CUTAWAY  /  MOTION SLOWED","","#ff956e");
}
function roundRect(x,y,w,h,r,fill,stroke,width=2) {
  g.beginPath();g.roundRect(x,y,w,h,r);
  if(fill){g.fillStyle=fill;g.fill();}
  if(stroke){g.strokeStyle=stroke;g.lineWidth=width;g.stroke();}
}
function battery(x,y,w,h,t){
  glow(x+w/2,y+h/2,w*1.18,"#8ab339");
  roundRect(x,y,w,h,13,"#21342b",pal.lime,4);roundRect(x+w,y+h*.34,17,h*.32,3,pal.lime);
  for(let i=0;i<4;i++)roundRect(x+16+i*(w-24)/4,y+15,(w-24)/4-7,h-30,3,pal.lime);
  if(t>0)circle(x+w+20,y+h/2,4,pal.lime);
}
function vectorRocket(x,y,t,s=1) {
  g.save();g.translate(x,y);g.scale(s,s);
  const plume=gradient([[0,"#ffffc5"],[.31,"#ffb55d"],[.66,"#f45c29a8"],[1,"#f45c2900"]],0,110,0,320);
  g.fillStyle=plume;g.beginPath();g.moveTo(-27,117);g.bezierCurveTo(-86,189,-61,272,-8,324+15*Math.sin(t*16));g.bezierCurveTo(62,254,82,177,26,117);g.closePath();g.fill();
  glow(0,157,95,"#e76a34");
  g.fillStyle=gradient([[0,"#242934"],[.46,"#9aabb4"],[.71,"#454f5b"],[1,"#141a23"]],-42,0,42,0);
  g.beginPath();g.moveTo(-38,111);g.lineTo(-31,-116);g.quadraticCurveTo(-28,-170,0,-213);g.quadraticCurveTo(28,-170,31,-116);g.lineTo(38,111);g.closePath();g.fill();
  line([[-30,-113],[30,-113]],"#e9f5fbbf",2);
  line([[-37,65],[37,65]],"#e9f5fb80",2);
  line([[-26,112],[-30,124],[30,124],[26,112]],"#e9f5fb",2);
  g.restore();
}
function flowPath(points,color,t,speed=1) {
  line(points,color+"68",4);
  for(let i=1;i<points.length;i++){
    const p=(t*speed+i*.19)%1,x=lerp(points[i-1][0],points[i][0],p),y=lerp(points[i-1][1],points[i][1],p);
    glow(x,y,21,color);circle(x,y,5,color);
  }
}
function rutherford(t) {
  if(t<3.05) {
    background("#15343b","#090d14"); grid(55,"#a4e8ff13",t*12);
    if(media.launch){
      image("launch",650,0,630,720,1.75+.11*range(t,0,3.05),.55,.64);
      box(0,0,W,H,gradient([[0,"#0a131be8"],[.49,"#0a131bea"],[.72,"#0a131b00"]]));
    } else vectorRocket(947,343-60*range(t,0,3.05),t,1.2);
    battery(69,170,178,79,t);
    const a=1-range(t,1.1,2.96);g.save();g.globalAlpha=a;
    kick("RUTHERFORD  /  ELECTRON",56,72,pal.lime);
    big("BATTERIES?",49,410,107);text("INSIDE A ROCKET",56,466,24,pal.ice,750,"left",true);g.restore();
    footer(media.launch?"ARCHIVE PHOTO + SCHEMATIC":"SCHEMATIC  /  ELECTRON",media.launch?"NASA / PATRICK BLACK":"",pal.lime);return;
  }
  background("#10282a","#070d14");grid(52,"#a4e8ff18",t*4);
  const fluids=t>=7.8, cluster=t>=15.25;
  kick(cluster?"ELECTRON  /  FIRST-STAGE ENGINE CLUSTER":"RUTHERFORD  /  FOLLOW THE FLOW",55,71,pal.lime);
  if(cluster){
    const x=896,y=350;
    for(let i=0;i<9;i++){
      const a=i*PI/4, rr=i===8?0:151;
      const cx=x+Math.cos(a)*rr,cy=y+Math.sin(a)*rr;
      glow(cx,cy,71,"#ff9e54");circle(cx,cy,49,"#282832","#ff9e54",2);circle(cx,cy,27,"#101b20","#8ce6f3",1);
    }
    big("9",48,441,243,pal.lime);big("ENGINES",222,417,76);
    text("FIRST STAGE",59,504,24,pal.ice,750,"left",true);
    footer("SCHEMATIC  /  NOZZLE POSITIONS SIMPLIFIED","",pal.lime);return;
  }
  const labels=["LOX","KEROSENE"],ys=[241,439],cols=[pal.ice,pal.amber];
  battery(64,320,145,61,t);
  text("BATTERY",63,420,23,pal.lime,800,"left",true);
  for(let i=0;i<2;i++){
    const y=ys[i],k=cols[i];
    flowPath([[226,350],[309,350],[309,y],[412,y]],pal.lime,t,.8);
    roundRect(412,y-36,166,73,9,"#17292e",pal.lime,2);
    text("MOTOR",495,y+8,23,pal.lime,800,"center",true);
    line([[578,y],[663,y]],pal.paper,4);
    circle(706,y,42,"#15222a",k,2);
    for(let n=0;n<4;n++){const a=n*PI/2+t*4;line([[706,y],[706+26*Math.cos(a),y+26*Math.sin(a)]],k,4);}
    text("PUMP",706,y+73,20,k,750,"center",true);
    if(fluids){
      text(labels[i],803,y-25,17,k,750,"left",true);
      flowPath([[748,y],[927,y],[927,340],[1005,340]],k,t,.98);
    }
  }
  if(fluids){
    const hot=range(t,8.5,10.9);
    glow(1051,340,105*hot+8,"#fa7e4d");
    roundRect(1005,287,157,106,11,"#492e23","#ff9f57",2);
    text("CHAMBER",1083,347,20,pal.paper,800,"center",true);
    line([[1162,317],[1225,288],[1225,392],[1162,364]],pal.amber,4);
  }
  footer(fluids?"FLUID PATHS  /  OXYGEN + KEROSENE":"ELECTRIC PATH  /  BATTERY → MOTOR", "SIMPLIFIED ENGINE SCHEMATIC",pal.lime);
}
const animations={voyager:signal,artemis:moon,detonation,rutherford};
window.renderFrame=async function(t) {
  for(const v of cfg.videos||[]){
    const target=v.at(t), el=media[v.key];
    if(target===null||!el?.videoWidth||Math.abs(el.currentTime-target)<.015)continue;
    await new Promise(resolve=>{
      let timeout;
      const done=()=>{clearTimeout(timeout);el.removeEventListener("seeked",done);resolve();};
      el.addEventListener("seeked",done,{once:true});timeout=setTimeout(done,800);
      el.currentTime=Math.min(el.duration-.05,Math.max(0,target));
    });
  }
  animations[cfg.id](t);
};
window.ready=(async function(){
  await Promise.all(Object.entries(cfg.images).map(async ([key,src])=>{
    const i=new Image();i.src=src;await i.decode();media[key]=i;
  }));
  await Promise.all((cfg.videos||[]).map(v=>new Promise((resolve,reject)=>{
    const el=document.createElement("video");el.src=v.src;el.muted=true;el.preload="auto";el.playsInline=true;
    el.addEventListener("loadeddata",()=>{media[v.key]=el;resolve();},{once:true});
    el.addEventListener("error",()=>reject(new Error("Cannot load "+v.src)),{once:true});
  })));
  await window.renderFrame(0);return true;
})();
