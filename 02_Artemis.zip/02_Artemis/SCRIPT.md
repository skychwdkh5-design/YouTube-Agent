# Orbital Atlas — Five Flashes on the Moon

**Title** NASA Astronauts Saw Five Flashes on the Far Side of the Moon  
**Voice** Adam · EN-US · 16:9 · 1080p30 · target 2:40–3:05 after read

## Packaging before the timeline

- **A / selected** FIVE FLASHES. The annotated Moon on the right. Paper-white text on the left, restrained red circles only at the crew's actual marks inside the original document. Frame 0 is the cover.
- **B** NO RADIO. The backlit lunar rim fills the image while a thin signal line ends behind the Moon. The payoff is how the crew delivered its observations.
- **C** THEY SAW IT. A large inset from the crew’s sketch beside a real lunar rim. The payoff is how three people compared notes.

## EN narration and cut plan

### 00:00–00:21 | The evidence, immediately

Five pinpricks of light appeared on the dark Moon. Three astronauts aboard NASA's Artemis Two mission marked where they saw them. Orion was about forty-six thousand miles away. And at that point in the flyby, the Moon was between the spacecraft and Earth. Here's what the crew could see while Mission Control was out of reach.

**Picture** 0–2.8 frame 0 moves into the original notes. 2.8–6.2 annotated image, full panel and credit. 6.2–10.5 real eclipse imagery into controlled lunar limb reveal. 10.5–15 animated Earth–Moon–Orion geometry. 15–21 return to notes. Dim perimeter, hold the important marks still long enough to read.

### 00:21–00:52 | Where the radio went

When Orion moved behind the Moon, the crew knew radio contact with Earth would drop. The Moon itself blocked the direct path. For a while, the people aboard Orion could keep watching and recording, while people on the ground had to wait for contact to return.

This was a rare chance to watch the dark lunar surface. Without the bright face of the Moon dominating the view, a short flash could stand out. The science team had asked the astronauts to look for exactly that.

**Picture** Begin with the diagram already in motion. One orbital arc, line of sight visible, Moon occludes it. Switch from geometry to the NASA footage. Label visuals ARCHIVE or SCHEMATIC. Keep the scale disclaimer on the diagram.

### 00:52–01:28 | What makes a pinprick

Picture a small piece of rock moving through space. At the Moon, there's no thick atmosphere for it to cross. It can hit the surface at high speed. A little of the impact energy can appear as a brief flash.

From Orion, that flash was a pinprick. Now look at the annotations. Reid Wiseman marked his observations in blue, Victor Glover in green, and Jeremy Hansen in red. General annotations are in purple. The drawing is their record of where they saw light. It gives scientists something they can compare across observers.

**Picture** Show one restrained impact pulse as an explicit schematic. No giant crater, no exploding lunar globe. Cut to the original annotations, preserve their legend and actual placement. Use crop positions from the real source, never relabel the original marks.

### 01:28–02:02 | The right kind of proof

An astronaut seeing a flash and a camera capturing it are two different things. The images give us the crew’s view of the Moon. Their notes tell us where they saw the pinpricks. Put those together and you can reconstruct what they reported, including cases where crew members thought they had seen the same event.

Once communications came back, the observations could reach the ground. That's when the view from Orion became evidence the lunar science team could examine alongside the rest of the flyby record.

**Picture** Triptych: lunar photo, original annotation, report. Reveal each on the relevant word. Use an on-screen split that keeps the notes readable on iPad. NASA's short footage is available with third-party music. Supplied excerpt is mute.

### 02:02–end | Why bother watching

This is why scientists asked a crew flying around the Moon to spend part of the trip staring into darkness. A flash disappears almost as soon as it arrives. An observer who records where it happened can leave a trace of the event long after the light is gone.

That makes these little marks worth a second look. They show what three people thought they saw in the dark, while the rest of us were on the other side of the Moon.

**Picture** End on the crew's original annotated image, then pull back to the full document. Land on one quiet cut to black after VO. Avoid an outro over the closing evidence.

## Sources and media

- NASA preliminary lunar science report and original annotation, including figure qualification and credits. https://science.nasa.gov/feature/artemis-ii-preliminary-lunar-science-report/
- NASA annotation card. https://www.nasa.gov/image-article/artemis-ii-crew-moon-photo-annotations/
- NASA SVS 15103 footage. https://svs.gsfc.nasa.gov/15103/ — mute source audio unless the independently cleared cue or a verified isolated NASA voice track is used.
- NASA lunar flyby gallery. https://www.nasa.gov/gallery/lunar-flyby/
- NASA media guidelines. https://www.nasa.gov/nasa-brand-center/images-and-media/
