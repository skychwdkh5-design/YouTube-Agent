# Orbital Atlas EP009 — ILLUSTRATIVE CUTOUT ASSETS (PREPRODUCTION)

These eight image files are PNG RGBA assets with recorded pixel dimensions and SHA-256. They use the owner-approved hand-painted sculptural editorial look. These are precomposed 2.5D layers, **NOT** rotatable rigged 3D meshes or real tornado/observation footage. The package includes an asset contact sheet.

**Not in GitHub yet:** download and attach this ZIP to Claude's conversation or upload each PNG to the EP009 repository asset folder. Refer to assets.json for full hashes. Do not assume Claude can access sandbox links or files.

**Documentary files missing:** NASA EO-1 Tuscaloosa May 2, NASA Aqua MODIS Apr12/Apr28, NOAA GOES timelapse. Original source pages and credit lines must be verified before full render.

**Label:** ILLUSTRATION / NOT TO SCALE for reconstructed scenes. The shown farmhouse and storm are hypothetical. No license is granted to portray them as footage from 2011.

**QA:** edges in generated PNGs may contain colored matte contamination and should be checked on a contrasting background. Separate markers from spritesheet and cloud layers only if an animation requires independent pieces.
